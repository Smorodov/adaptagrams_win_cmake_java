cmake-swig-java-example
=======================

An example of combining cmake, swig and java and generating a Jar with native inside
